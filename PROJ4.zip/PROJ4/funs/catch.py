import subprocess as sub
import time

# have to drop port 22 because of noise of ssh connevtion
def catch(INTERFACE = 'eth0'):
    print('dumping')
    start = time.time()
    S=''
    p = sub.Popen(('tcpdump', '-i',INTERFACE,'port','not','22','-w','cap.pcap'), stdout=sub.PIPE)
    while True:
        if time.time()>start+5:
            p.send_signal(subprocess.signal.SIGTERM)
            return 0
            
                    
