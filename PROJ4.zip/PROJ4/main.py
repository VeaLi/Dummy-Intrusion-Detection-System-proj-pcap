from funs.build_dict import build_dict
from funs.agg import agg
from funs.primary import primary
from funs.secondary import secondary
from funs.catch import catch
import pickle
import pandas as pd
import time
import numpy as np
import os
import warnings

# have to drop absurdly high correlated features (because not enough data)
def drop(df):
    for col in list(df):
        if 'src' in col or 'dst' in col:
            df.drop(col,axis=1,inplace=True)
    return df


def main(I = 'eth0',drop=drop):

    #this is absolutely safe
    def warn(*args, **kwargs):
        pass
    warnings.warn = warn

    #reading basic models + with l2 penalty
    binary = pickle.load(open('funs/model_data/binary', 'rb'))
    model = primary(model=binary)

    #iterations trunked
    multi = pickle.load(open('funs/model_data/multi', 'rb'))
    model_ = secondary(model=multi)
    
    while True:
        #that is not so ok exception if something will go wrong
        try:

            #that's an ok exception            
            try:
                os.remove('cap.pcap')
            except:
                #no such file
                pass
            
            catch(I) # writing to dump
            df = build_dict()
            df = agg(df)
            statinfo = os.stat('cap.pcap')
            df['size'] = statinfo.st_size # there is about 200000 features in pcap that wiresahrk can offer let's consider files size atleast!
            df = drop(df)
            model.data = df # building record
            res,resb = model.predict() # predict label for record

            #this model have not seen much things, and it is quite scared
            d = {0:'no anomalies',1:'it looks like an anomaly'}
            
            print(res[0],' ',end='')
            print(d[resb[0]], time.ctime(),'\n')

            #custom threshold
            if resb[0]==1 and res[0]>.53:
                print('it can be ...')
                model_.data = df
                res,labels = model_.predict()

                for l,r in zip(labels,res[0]):
                    if l!='normal':
                        print('-'*(1+int(str(r)[2])),r," : ",l)
            
            
        except:
            print(time.ctime())










if __name__ == '__main__':
    main()
