from funs.build_dict import build_dict
from funs.agg import agg
from funs.primary import primary
from funs.secondary import secondary
from funs.catch import catch
import pickle
import pandas as pd
import time
import numpy as np


def main(I = 'eth0'):
    binary = pickle.load(open('funs/model_data/binary', 'rb'))
    model = primary(model=binary)

    multi = pickle.load(open('funs/model_data/multi', 'rb'))
    model_ = secondary(model=binary)
    
    while True:
        catch(I) # writing to dump
        df = build_dict()
        df = agg(df)
        statinfo = os.stat('cap.pcap')
        df['size'] = statinfo.st_size # there is about 200000 features in pcap that wiresahrk can offer let's consider files size atleast!
        model.data = df # building record
        res,resb = model.predict() # predict label for record
        d = {0:'no anomalies',1:'oh, dear it looks like anomaly'}
        print(res[0],' ',end='')
        res[0] = int(res[0]>0.7)
        print(d[res[0]], time.ctime())
        if resb[0]==1:
            print('let me see what it can be ...')
            model_.data = df
            res,labels = model_.predict()

            #dd = dict(zip(labels,res))
            #dd = sorted(dd.items,key = lambda x: x[1],reverse=True)
            
            for l,r in zip(labels,res):
                print(l," : ",'-'*(1+int(str(r)[2])),r)
            










if __name__ == '__main__':
    main()
