
class secondary(object):
    def __init__(self,model=None):
        self.model = model
        self.res = None
        self.data = None
        self.labels = ['capture_flag', 'infect', 'normal', 'scan', 'unrecognized_anomaly']


    def predict(self):
        #self.res = self.model.predict_proba(self.data)
        self.model.predict(self.data)
        return (self.res,self.labels)
        
        
